package act1Servidor;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

public class Client {
	public static void main(String args[])
	{
		try {
			//Conexion.
			Socket clientSocket=new Socket("localhost", 3000);
	
			//Recibir datos.
			DataInputStream entradaCliente = new DataInputStream(clientSocket.getInputStream());
			//Interpretar datos.
			String messageFromServer = entradaCliente.readUTF();
			//Mostrar datos.
			System.out.println("Mesaje recibido del servidor: " + messageFromServer);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}

}
