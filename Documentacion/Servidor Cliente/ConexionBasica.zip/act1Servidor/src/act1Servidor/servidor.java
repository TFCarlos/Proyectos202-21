package act1Servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class servidor {

	public static void main(String[] args){
		
		ServerSocket server = null;
		Socket connectionSocket = null;
		DataInputStream entradaServidor = null;

		try {
			System.out.println("Iniciando servidor");
			//Creacion de puerto.
			server= new ServerSocket(3000);
			//Siempre escuchando
			while(true) {
				//Aceptar todas las conexiones.
				connectionSocket = server.accept();
				//Escuchando lo que le envie el cliente (Input)
				entradaServidor = new DataInputStream(connectionSocket.getInputStream());
				//Devuelve mensaje (Output) a la conexion (connectionSocket)
				DataOutputStream MessageToClient = new DataOutputStream(connectionSocket.getOutputStream());
				//Mensaje en UTF
				MessageToClient.writeUTF("La conexi�n ha sido exitosa");
				//Almacena
				MessageToClient.flush();
				//Cierra
				MessageToClient.close();
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}

	}

}
